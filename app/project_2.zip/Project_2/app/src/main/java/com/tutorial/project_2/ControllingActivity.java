package com.tutorial.project_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.content.Intent;
import android.os.Bundle;

public class ControllingActivity extends AppCompatActivity {
    SwitchCompat switchCompat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controlling);

        switchCompat = findViewById(R.id.sw_heater);
        switchCompat = findViewById(R.id.sw_cooler);
        switchCompat = findViewById(R.id.sw_phasam);
        switchCompat = findViewById(R.id.sw_phbasa);
        switchCompat = findViewById(R.id.sw_aerator);
        
    }
    
    @Override
    public void onBackPressed() {
        Intent goHome = new Intent(ControllingActivity.this, HomeActivity.class);
        startActivity(goHome);
        finish();
    }
}