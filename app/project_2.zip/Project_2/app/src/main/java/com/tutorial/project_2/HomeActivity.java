package com.tutorial.project_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity  {

    private long backPressTime;
    private Toast backToast;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mAuth = FirebaseAuth.getInstance();

        CardView CvMonitoring  = findViewById(R.id.btn_monitoring);
        CvMonitoring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goMonitoring = new Intent(HomeActivity.this, MonitoringActivity.class);
                startActivity(goMonitoring);
                finish();
            }
        });

        CardView CvControlling  = findViewById(R.id.btn_controlling);
        CvControlling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goControlling = new Intent(HomeActivity.this, ControllingActivity.class);
                startActivity(goControlling);
                finish();
            }
        });

        Button btnLogout = findViewById(R.id.btn_Logout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent goLogin = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(goLogin);
                finish();
            }
        });

    }

//    @Override
//    public void onStart() {
//        super.onStart();
//        // Check if user is signed in (non-null)
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        if(currentUser == null){
//            startActivity(new Intent(HomeActivity.this, RegisterActivity.class));
//        }
//    }

    @Override
    public void onBackPressed() {
        if (backPressTime + 2000 > System.currentTimeMillis()){
            backToast.cancel();
            super.onBackPressed();
            finish();
        } else {
            backToast = Toast.makeText(getBaseContext(), "Press back again to Exit App", Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressTime = System.currentTimeMillis();
    }
}