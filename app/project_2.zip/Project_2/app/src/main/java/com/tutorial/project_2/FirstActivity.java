package com.tutorial.project_2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirstActivity extends AppCompatActivity {

    // inisialisasi TV
    TextView nilaiSuhu, nilaiPH, nilaiAmonia;

    // buat reference untuk FB (koneksi server / host FB)
    // public Firebase mRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);


        Button btnFirst = findViewById(R.id.first_button);
        btnFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goLogin = new Intent(FirstActivity.this, LoginActivity.class);
                startActivity(goLogin);
                finish();
            }
        });

        nilaiSuhu = findViewById(R.id.tv_nilai_suhu);

        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://project-2-baa43-default-rtdb.firebaseio.com/");
        DatabaseReference myRef = database.getReference("valueSuhu");

        myRef.setValue("Hello, World!");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String valueSuhu = snapshot.getValue(String.class);
                nilaiSuhu.setText(valueSuhu);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

/*
        // baca komponen nilai suhu (TextView)
        nilaiSuhu = findViewById(R.id.tv_nilai_suhu);
        // buka koneksi ke host FB
        mRef = new Firebase("https://project-2-baa43-default-rtdb.firebaseio.com/valueSuhu");

        // baca komponen nilai pH (TextView)
        nilaiPH = findViewById(R.id.tv_nilai_ph);
        // buka koneksi ke host FB
        mRef = new Firebase("https://project-2-baa43-default-rtdb.firebaseio.com/valuePH");

        // baca komponen nilai Amonia (TextView)
        nilaiAmonia = findViewById(R.id.tv_nilai_amonia);
        // buka koneksi ke host FB
        mRef = new Firebase("https://project-2-baa43-default-rtdb.firebaseio.com/valueAmonia");


        // proses RT
        mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // ambil nilai field valueSuhu
                String valueSuhu = dataSnapshot.getValue(String.class);
                // tampilkan di TV Suhu
                nilaiSuhu.setText(valueSuhu);

                // ambil nilai field valuePH
                String valuePH = dataSnapshot.getValue(String.class);
                // tampilkan di TV pH
                nilaiPH.setText(valuePH);

                // ambil nilai field valueAmonia
                String valueAmonia = dataSnapshot.getValue(String.class);
                // tampilkan di TV Amonia
                nilaiAmonia.setText(valueAmonia);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
*/

    }


}